<?php

namespace App\Http\Controllers;

use App\Models\Desa;
use App\Models\HalamanData;
use App\Models\HalamanData2;
use App\Models\Pendaftaran;
use App\Models\Tematik;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Alert;
use App\Models\Daftar;

class RouteMap extends Controller
{
  


    
}
