<?php

namespace App\Http\Controllers;

use App\Models\HalamanData;
use Illuminate\Http\Request;

class DataController extends Controller
{
    public function places()
    {
     
    }
}
